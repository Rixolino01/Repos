1. Instalar as depend.
2. Ajustar o .env
3. Ajustar o schema.prisma